  CREATE  TABLE "RBR"."Z44test" 
   (    "Z44CLOB" CLOB, 
    "Z44STRF" NUMBER(11,0), 
    "Z44RQID" VARCHAR2(60), 
    "Z44SSID" VARCHAR2(60), 
    "Z44RQTP" VARCHAR2(60), 
    "Z44SSYN" VARCHAR2(80), 
    "Z44DSYN" VARCHAR2(80), 
    "Z44CUID" VARCHAR2(80), 
    "Z44DLLN" VARCHAR2(254), 
    "Z44PMOD" NUMBER(2,0), 
    "Z44ATYP" VARCHAR2(30), 
    "Z44SERR" VARCHAR2(4000)
   ) 

-- DELETE FROM "RBR"."Z44test" ;
-- INSERT INTO "RBR"."Z44test" (z44clob, z44strf, z44rqid, z44ssid, z44rqtp, z44ssyn, z44dsyn, z44cuid, z44dlln, z44pmod, z44atyp, z44serr)   VALUES (null, 1, 'Z44RQID', 'Z44SSID', 'Z44RQTP', 'Z44SSYN', 'Z44DSYN', 'Z44CUID', 'Z44DLLN', 1, 'Z44ATYP', 'Z44SERR');
-- select * from "RBR"."Z44test" ;